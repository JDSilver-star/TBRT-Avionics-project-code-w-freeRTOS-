endblock
--------

.. versionadded:: 3.25

Ends a list of commands in a :command:`block` and removes the scopes
created by the :command:`block` command.

.. code-block:: cmake

  endblock()
