CTEST_USE_LAUNCHERS_DEFAULT
---------------------------

.. include:: include/ENV_VAR.rst

Initializes the :variable:`CTEST_USE_LAUNCHERS` variable if not already defined.
