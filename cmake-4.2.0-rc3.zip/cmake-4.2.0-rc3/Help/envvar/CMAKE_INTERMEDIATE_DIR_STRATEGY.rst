CMAKE_INTERMEDIATE_DIR_STRATEGY
-------------------------------

.. versionadded:: 4.2

.. include:: include/ENV_VAR.rst

``CMAKE_INTERMEDIATE_DIR_STRATEGY`` is a string specifying the strategy to use
for target intermediate directories. It initializes the
:variable:`CMAKE_INTERMEDIATE_DIR_STRATEGY` variable.
