#pragma once

namespace mathfunctions {
double OpMul(double a, double b);
}
